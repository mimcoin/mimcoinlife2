# MIM Coin Life

This is the full website for **MIM Coin Life**.

## 🔧 How to Use

1. Replace the image files in the `/images` folder with your own:
   - `logo.png`
   - `motorcycle.jpg`
   - `bar.jpg`

2. Upload the full folder to your GitHub repo.

3. Redeploy on Vercel — done.

Your site will now load on your custom domain (e.g. mimcoinlife.com).

No backend, no frameworks — this is a pure HTML/CSS luxury meme brand site.
